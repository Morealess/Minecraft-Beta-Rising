IF you clicked here, you can alternatively opt into using Cascades to completely overhaul the selected worldtype's terrain generation. It's described as "Hybrid Beta" and is just that, for example you will see both beta and modern caves, larger continents and regions, arguably better terrain, and much more: https://modrinth.com/datapack/hybrid-beta 

To use Cascades, replace "Default.zip" with it. (in .minecraft/kubejs/data)



Notes: 

1. If you are not using Cascades, then the "Default" datapack should be used. Without it, Durium Ore, Wild Crops, and Solium Moss will not generate in Modern Beta worlds so this fixes that.

2. Modern Beta presets will be completely unique from their descriptions with Cascades!

3. Any files in "Alt-Terrain-Generation-Pack.zip" will not get loaded.

