IF you clicked here, you can alternatively opt into using Cascades' terrain generation instead of Modern Beta. It's described as "Hybrid Beta" and is just that, for example you will see both beta and modern caves and much more. 

To use Cascades, replace "Default.zip" with it. 



Notes: 

1. If you are not using Cascades, then the default datapack should be used, with "Default.zip" in .minecraft/kubejs/data. (Without it; Durium Ore, Wild Crops, and Solium Moss will not generate in Modern Beta worlds).

2. Modern Beta presets will be completely altered from Cascades!

3. Any files in "Alt-Terrain-Generation-Pack.zip" will not get loaded.

