This pack was created with modularity in mind and is separate from Beta Rising.

SUPER IMPORTANT NOTE: Also... 

-<!> You will need to manually rename/replace the file "icons.png" yourself if you plan to use this pack elsewhere! (blame mojang) KAPEESH? <!>
-Due to the nature of overlapping elements from simply changing anything in "assets/minecraft/textures/gui/icons.png", I also had to replace the food icons as hearts to show food replenishment tooltips heal health not food, as this pack was primarily built for the Beta Rising modpack... which doesn't use hunger. 
-Included is a alternate/interchangeable version of "icons.png", which uses Golden Days' top half of the image (regular food icons) and only replaces the exp bar.